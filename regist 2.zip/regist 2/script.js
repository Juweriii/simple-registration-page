document.getElementById("btnlogin").addEventListener("click", function () {
    document.getElementById("Register").style.display = "none";
    document.getElementsByClassName("form-container").style.display = "block";
  });
  

